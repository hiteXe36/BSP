#!/bin/bash
#The first shellscript for BSP
#Paul Mathia & Dennis Sentler | paul.mathia@haw-hamburg.de & dennis.sentler@haw-hamburg.de  
#15.04.2018 
#Version 1.0

#Globale Variablen 
SIZE=10             #standard wert 10 - 10lines(txt) oder 10Kb andere files.
verboseFlag=0       #verbose modus ist anfänglich ausgeschaltet 

#Hilfe Funktion zur nur Nutzung von Splitfix.sh
helpFunction()
{
    echo        "Description:      
                splitfix.sh [OPTIONS] FILE [FILE...] Splits FILE into
                fixed size pieces. 
                
                The pieces are 10 lines long, 
                if FILE is a text file.
                
                The pieces are 10kB long, 
                if FILE is *not* a text file. 
                
                The last piece of the splitted file may be smaller,
                it contains the rest of the original file.
                
                The output files bear the name of the input file 
                with a 4 digit numerical suffix.
                
                The original file can be reconstructed with the 
                command ''cat FILE.*''
    
                EXAMPLE: 
                splitfix.sh foo.pdf
                splits foo.pdf into the files foo.pdf0000 foo.pdf0001 etc.
    
                splitfix.sh -h | --help - displays this help text
                splitfix.sh --version  - prints the version number
        
                OPTIONS:
                -h 
                    --help      this help text
    
                -s SIZE         size of the pieces 
                                in lines for a text file
                                or in kBytes for other files
    
                -v
                    --verbose   prints debugging messages"
}

version()
{
    echo "splitfix.sh Versionsnummer: 1.0"
}

#Funktion zum setzen der neuen SIZE -funktioniert nicht
setSize()
{
    echo $1 | grep "[^0-9]"
    if [ "$?" -eq "0" ]
        then
        exit 1
    fi
    
    SIZE=$1;
}


###########################################--- MAIN-Methode ---###########################################
#case: programm ohne parameter aufgerufen
if [ $# -eq 0 ]
    then echo "Programm ohne Parameter aufgerufen!"
    helpFunction
fi

#solange die Parameteranzahl != "" ist jeden Parameter verarbeiten. 
while [ "$1" != "" ]; do


        case $1 in 
                "-h" | "--help")
                    helpFunction
                    exit 1
                    ;;
                "-s")
                    setSize
                    shift #auch falsch
                    shift #klappt nicht
                    ;;
                "-v" | "--verbose")
                    verboseFlag=1 #debug informationen mit ausgeben
                    echo "Verbose-Modus aktiv!"
                    ;;
                "--version")
                    version
                    exit 1
                    ;;
                *) 
                    echo "File wird verarbeitet"

#jetzt ums verarbeiten des Fileparameters kümmern
# -i = ignore cases
    file --mime-type $1 | grep -i text
                #fallunterscheidung: return code 0, also positives ergebnis des letzten commands dann handelt es sich wohl um ein textfile
                if [ $? -eq 0 ]  
                    then
                      if [ $verboseFlag -eq 1 ]
                        then
                            echo "File ist eine Textdatei"
                            echo "File wird gesplittet..."
                            split --verbose -a4 -d -l$SIZE $1 $1.
                        else
                            split -a4 -d -l$SIZE $1 $1.
                        fi
                #alles ungleich einer text file        
                else
                    if [ $verboseFlag -eq 1 ]    
                        then
                            echo "File ist keine Textdatei"
                            echo "File wird gesplittet..."
                            split --verbose -a4 -b "$SIZE"K -d $1 $1.
                    else
                            split -a4 -b "$SIZE"K -d $1 $1.
                    fi
                fi
    esac
       
shift 
done    
    
    
